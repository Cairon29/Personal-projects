import { useState, useEffect } from 'react'

import { SearchInput, Form, LostItem } from './components'
import services from './services/dbServices'


function App() {
  const [lostItems, setLostItems] =  useState([])
  const [search, setSearch] =  useState('')

  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [date, setDate] = useState('')
  const [foundIn, setFoundIn] = useState('')
  
  useEffect(() => {
    services.getLostItems()
    .then(data => setLostItems(data))
  }, [])
  
  /* SEARCH */

  const handleInputSearch = (e) => {
    setSearch(e.target.value)
    console.log(e.target.value)
    
  }

  /* FORM SETTINGS */
  const handleFormName = (e) => {
    setName(e.target.value)
  }
  const handleFormDescription = (e) => {
    setDescription(e.target.value)
  }
  const handleFormDate = (e) => {
    setDate(e.target.value)
  }

  const handleFormFoundIn = (e) => {
    setFoundIn(e.target.value)
  }
  const handleFormSubmit = (e) => {
    e.preventDefault()
    console.log(name, description, foundBy, foundIn)
  }

  const handleDeleteLostItem = () => {
    console.log('trying to delete');
    console.log(lostItems);
    
  }

  

  return (
    <>
      <SearchInput search={search} handleSearch={handleInputSearch}/>
      <section>
        <h2>Items perdidos</h2>
        {
          !lostItems 
          ? <p>No hay items perdidos</p>
          : lostItems.map((item) => (
            <LostItem key={item.Id_Objeto} lostItem={item} handleFound={handleDeleteLostItem}/>

          ))
        }
      </section>
      <Form 
          name={name} handleName={handleFormName}
          description={description} handleDescription={handleFormDescription}
          date={date} handleDate={handleFormDate}
          foundIn={foundIn} handleFoundIn={handleFormFoundIn}
          handleSubmit={handleFormSubmit}
      />
    </>
  )
}

export default App
