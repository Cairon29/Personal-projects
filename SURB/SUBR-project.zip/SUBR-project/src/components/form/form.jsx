export const Form = ({name, handleName, description, handleDescription, date, handleDate, foundIn, handleFoundIn, handleSubmit}) => {
  return (
    <form onSubmit={handleSubmit}>
        <input type="text" value={name} onChange={handleName}/>
        <input type="text" value={description} onChange={handleDescription}/>
        <input type="date" value={date} onChange={handleDate}/>
        <input type="text" value={foundIn} onChange={handleFoundIn}/>
        <button type="submit"> Añadir</button>
    </form>
  )
}
